function TT_FindApi(win){
  var cur = win; var depth = 0;
  while(cur && depth < 20){
    try {
      if(cur.API_1484_11) return { api: cur.API_1484_11, version: '2004' };
      if(cur.API) return { api: cur.API, version: '1.2' };
      if(cur.parent && cur.parent !== cur) cur = cur.parent; else break;
    } catch(e) { break; }
    depth += 1;
  }
  return null;
}
window.TT_SCORM = TT_FindApi(window);
window.TT_SCORM_READY = !!window.TT_SCORM;